
module.exports = {
    currentAge:                             40,
    RetirementAge:                          68,
    currentAnnualIncome:                    10000,
    spouceAnnualIncome:                     75000,
    currentRetirementSavings:               500000,
    currentRetirementContribution:          10,
    annualRetirementContributionIncrease:   .25,
    socialSecurityOverride:                 "yes",
    relationShipStatus:                     "married",
    socialSecurityOverride:                 4000,
    additionalIncome:                       500,
    noOfyearsRetirementNeedstoLast:         20,
    postRetirementIncreaseWithInflation:    "Yes",
    percentOfFinalAnnualIncomeDesired:      75,
    preRetirementInvestmentreturn:          8,
    postRetirementInvestmentreturn:          5

};